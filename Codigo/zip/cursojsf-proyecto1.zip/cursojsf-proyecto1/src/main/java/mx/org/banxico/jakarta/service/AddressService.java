package mx.org.banxico.jakarta.service;

import mx.org.banxico.jakarta.entity.Customer;

public interface AddressService {

	public void saludar();
	public void setCustomer(Customer customer);
	public void imprimirCustomer();
}
