package mx.org.banxico.jakarta.entity;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class City {

	private Integer id;
	private String city;
}
