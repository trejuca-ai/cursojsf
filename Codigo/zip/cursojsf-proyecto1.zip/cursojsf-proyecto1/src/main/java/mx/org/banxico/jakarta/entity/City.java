package mx.org.banxico.jakarta.entity;

public class City {

	private Integer id;
	private String city;
}
