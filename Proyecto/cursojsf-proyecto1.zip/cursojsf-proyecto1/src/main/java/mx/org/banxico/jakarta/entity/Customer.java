package mx.org.banxico.jakarta.entity;

import java.time.LocalDate;
import java.util.Date;

public class Customer {

	private Integer id;
	private Integer storeId;
	private String firstName;
	private String lastName;
	private String email;
	private Boolean active;
	private Integer addressId;

}
